---
name: Assign Issue
about: "(For internal use)"
title: ''
labels: ''
assignees: ''

---

**Feature description**
`Detailed description here`

**Expected output**
`description`

- [ ] Feature 1
- [ ] Feature 2
- [ ] Feature 3

**Tests instructions**
- Unit tests
- Integration tests

**References Material**
- Technical Specs
- Related docs
- Example code

**Additional Information**
