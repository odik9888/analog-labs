# frost-evm
FROST threshold signatures adapted for efficient verification in the EVM.

## License
Apache-2.0 OR MIT