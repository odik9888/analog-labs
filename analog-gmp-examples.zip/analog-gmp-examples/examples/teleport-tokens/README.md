# Teleport Tokens

This example demonstrates how teleport an ERC20 from Alice's account in Shibuya to Bob's account in Sepolia.

## License

Analog's Examples is released under the [MIT License](../../LICENSE).
