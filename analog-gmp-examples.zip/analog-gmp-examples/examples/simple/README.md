# Simple Counter

This example demonstrates how to relay a message from a source-chain to a destination-chain.

## License

Analog's Examples is released under the [MIT License](../../LICENSE).
